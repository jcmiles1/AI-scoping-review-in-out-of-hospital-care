# Data dictionary (auto-generated draft)

## Sheet: Information

| Column | Type (inferred) | Non-null | Example values |
|---|---|---:|---|
| `Publication Year` | int64 | 236/236 | 2023; 2022; 2020 |
| `Author` | object | 236/236 | Abbott, E. E.; Oh, W.; Dai, Y.; Feuer, C.; Chan, L.; Carr, B. G.; Nadkarni, G. N.; Abreu, P.; Santos, D.; Barbosa-Povoa, A.; Aguiar, M. Lg; Renteria, R. R.; Catumba-Ruiz, J.; Barrera, J. O.; Redondo, J. M. |
| `doi` | object | 229/236 | 10.2196/51844; ARTN 101492     10.1016/j.seps.2022.101492; RAYYAN-INCLUSION: {"Jamie"=>"Included", "Charlotte"=>"Maybe"} \| RAYYAN-LABELS: 3. Evolutionary ,B. Dispatch level |
| `Title` | object | 236/236 | Joint Modeling of Social Determinants and Clinical Factors to Define Subphenotypes in Out-of-Hospital Cardiac Arrest Survival: Cluster Analysis; Data-driven forecasting for operational planning of emergency medical services; Use of discrete event simulation and genetic algorithms to estimate the necessary resources to respond in a timely manner in the Medical Emergency System in Bogota |
| `Method` | object | 236/236 | 1. Classical Machine Learning; 2. Deep Learning; 3. Evolutionary |
| `Level` | object | 236/236 | A. System level; B. Dispatch Zone; C. Response Zone |
| `Application` | float64 | 0/236 |  |
| `Country` | object | 236/236 | USA; Portugal; Columbia |
| `Journal` | object | 230/236 | Comput Biol Med; Engineering Optimization; J Med Internet Res |
| `Manual Tags` | object | 226/236 | *Breast Neoplasms/diagnostic imaging; *Heart Diseases; Case-based reasoning; Decision path mining; Explainable machine learning; Female; Gbdt; Humans; Machine Learning; Paramedical diagnosis; Problem Solving; Tree-based model; -constraint method; Computational experiment; Deterministic modeling; Disaster; Dispatching problem; emergency medical services; Emergency services; Emergency vehicles; Genetic algorithms; Imperialist competitive algorithms; Large-scale problem; Meta heuristic algorithm; multi-objective imperialist competitive algorithm; Non dominated sorting genetic algorithm ii (NSGA II); non-dominated sorting genetic algorithm; NP-hard; Humans; emergency medical service; Machine Learning; Emergency Medical Service Communication Systems; trauma; Bayes Theorem; *Emergency Medical Dispatch; *Emergency Medical Services/methods; Bernoulli naive Bayes; dispatcher; emergency medical dispatch; frequency-inverse document frequency |
| `Note 1` | object | 207/236 | OHCA phenotyping; Predict demand; No full text on wales e-library |
| `Note 2` | object | 4/236 | also not 100 confident in objective if it is equation only no data; Sheffield has access but cannot download on our license; Rhythm interpretation |
| `Review notes` | object | 19/236 |   |
| `year` | int64 | 236/236 | 2023; 2022; 2020 |
| `month` | float64 | 174/236 | 12.0; 4.0; 7.0 |
| `day` | float64 | 74/236 | 6.0; 13.0; 1.0 |
| `journal` | object | 232/236 | JMIR Aging; Socio-Economic Planning Sciences; Medwave |
| `issn` | object | 231/236 | 2561-7605 (Electronic)     2561-7605 (Linking); 0038-0121; 0717-6384 (Electronic)     0717-6384 (Linking) |
| `volume` | float64 | 224/236 | 6.0; 86.0; 22.0 |
| `issue` | float64 | 143/236 | 1.0; 3.0; 13.0 |
| `pages` | object | 199/236 | e51844; e8718; 11497-11506 |
| `abstract` | object | 236/236 | BACKGROUND: Machine learning clustering offers an unbiased approach to better understand the interactions of complex social and clinical variables via integrative subphenotypes, an approach not studied in out-of-hospital cardiac arrest (OHCA). OBJECTIVE: We conducted a cluster analysis for a cohort of OHCA survivors to examine the association of clinical and social factors for mortality at 1 year. METHODS: We used a retrospective observational OHCA cohort identified from Medicare claims data, including area-level social determinants of health (SDOH) features and hospital-level data sets. We applied k-means clustering algorithms to identify subphenotypes of beneficiaries who had survived an OHCA and examined associations of outcomes by subphenotype. RESULTS: We identified 27,028 unique beneficiaries who survived to discharge after OHCA. We derived 4 distinct subphenotypes. Subphenotype 1 included a distribution of more urban, female, and Black beneficiaries with the least robust area-level SDOH measures and the highest 1-year mortality (2375/4417, 53.8%). Subphenotype 2 was characterized by a greater distribution of male, White beneficiaries and had the strongest zip code-level SDOH measures, with 1-year mortality at 49.9% (4577/9165). Subphenotype 3 had the highest rates of cardiac catheterization at 34.7% (1342/3866) and the greatest distribution with a driving distance to the index OHCA hospital from their primary residence >16.1 km at 85.4% (8179/9580); more were also discharged to a skilled nursing facility after index hospitalization. Subphenotype 4 had moderate median household income at US $51,659.50 (IQR US $41,295 to $67,081) and moderate to high median unemployment at 5.5% (IQR 4.2%-7.1%), with the lowest 1-year mortality (1207/3866, 31.2%). Joint modeling of these features demonstrated an increased hazard of death for subphenotypes 1 to 3 but not for subphenotype 4 when compared to reference. CONCLUSIONS: We identified 4 distinct subphenotypes with differences in outcomes by clinical and area-level SDOH features for OHCA. Further work is needed to determine if individual or other SDOH domains are specifically tied to long-term survival after OHCA.; Emergency medical services (EMS) play a vital role in delivering pre-hospital care. The operational efficiency of such services is critical and adequate demand forecasts can contribute to such a goal. But for that, the available data need to be well characterized before being used. Previous studies have failed to address some important aspects of this need, such as exploring a comprehensive list of contextual data to decide which are relevant to explain the EMS demand behavior. Moreover, modern forecasting techniques have been explored in the EMS context, including neural networks, but the computational complexity inherent to the methods and their use was not discussed. Finally, it is also unclear how different demand patterns can be when predicting the volume of emergency calls considering the priority level and the number of dispatches according to vehicle type. This study proposes a generic data-driven forecasting method to address these shortcomings and to support operational decisions. The results obtained with the proposed method indicate that each priority call and vehicle type shows different patterns, which suggests that such differentiation should contribute to better resource allocation. At the same time, the operational impact of the demand shared by neighboring zones proved to be significant at bases near the border. The models developed resulted in important decision tools that can be used to predict the dynamic demand of EMS on an hourly or shift basis. Additionally, the method adds value for decision-makers that want to plan not only when and how many but also where resources are demanded, avoiding assumptions that impact the operational performance.; INTRODUCTION: Bogota has a Medical Emergency System of public and private ambulances that respond to health incidents. However, its sufficiency in quantity, type and location of the resources demanded is not known. OBJECTIVE: Based on the data from the Medical Emergency System of Bogota, Colombia, we first sought to characterize the prehospital re- sponse in cardiac arrest and determine with the model which is the least number of resources necessary to respond within eight minutes, taking into account their location, number, and type. METHODS: A database of incidents reported in administrative records of the district health authority of Bogota (2014 to 2017) was obtained. Based on this information, a hybrid model based on discrete event simulation and genetic algorithms was designed to establish the amount, type and geographic location of resources according to the frequencies and typology of the events. RESULTS: From the database, Bogota presented 938 671 ambulances dispatches in the period. 47.4% high priority, 18.9% medium and 33.74% low. 92% of these corresponded to 15 of 43 medical emergency codes. The response times recorded were longer than expected, especially in out-of-hospital cardiac arrest (median 19 minutes). In the proposed model, the best scenario required at least 281 ambulances, medicalized and basic in a 3:1 ratio, respectively, to respond in adequate time. CONCLUSIONS: Results suggest the need for an increase in the resources that respond to these incidents to bring these response times to the needs of our population. |
| `doi.1` | object | 229/236 | 10.2196/51844; ARTN 101492     10.1016/j.seps.2022.101492; RAYYAN-INCLUSION: {"Jamie"=>"Included", "Charlotte"=>"Maybe"} \| RAYYAN-LABELS: 3. Evolutionary ,B. Dispatch level |
| `keywords` | object | 227/236 | Sdoh;algorithm;algorithms;association;associations;cardiac;cardiology;cluster;clustering;cohort;death;heart;k-means;machine learning;mortality;myocardial;observational;out-of-hospital-cardiac arrest;phenotype;phenotypes;retrospective;social determinants of health;subphenotype;subphenotypes;survival;survive;survivor;survivors; emergency medical services;forecasting;data-driven;neural networks;ems calls;ambulance service demand;ambulance location;neural-networks;demand;optimization;challenges;prediction;management;model; 10.5867/medwave.2022.03.002100     %(Uso de simulacion de eventos discretos y algoritmos geneticos para estimar los recursos necesarios para responder oportunamente en el sistema de emergencias medicas en Bogota. |

## Sheet: Sheet3

| Column | Type (inferred) | Non-null | Example values |
|---|---|---:|---|
| `Unnamed: 0` | object | 10/11 | Count of Level; Row Labels; A. System level |
| `Unnamed: 1` | object | 9/11 | Column Labels; 1. Classical Machine Learning; 14 |
| `Unnamed: 2` | object | 8/11 | 2. Deep Learning; 17; 3 |
| `Unnamed: 3` | object | 6/11 | 3. Evolutionary; 11; 13 |
| `Unnamed: 4` | object | 5/11 | 4. Natural Language; 2; 3 |
| `Unnamed: 5` | object | 8/11 | 5. Ensemble / Proprietary; 4; 9 |
| `Unnamed: 6` | object | 1/11 | (blank) |
| `Unnamed: 7` | object | 8/11 | Grand Total; 46; 32 |
| `Unnamed: 8` | object | 6/11 | Leanne; Charlotte L; Jamie |

## Sheet: Dump

| Column | Type (inferred) | Non-null | Example values |
|---|---|---:|---|
| `Country` | object | 236/236 | Iran; Japan; Saudi Arabia |
| `Unnamed: 1` | float64 | 0/236 |  |
| `Unnamed: 2` | float64 | 0/236 |  |
| `Unnamed: 3` | float64 | 0/236 |  |
| `Unnamed: 4` | object | 46/236 | Row Labels; USA; India |
| `Unnamed: 5` | object | 45/236 | Count of Country; 40; 22 |
| `Unnamed: 6` | float64 | 0/236 |  |
| `Unnamed: 7` | float64 | 0/236 |  |
| `Unnamed: 8` | object | 1/236 | Wrong Study Design (not AI), 14; Not Primary Research, 12;  Wrong Population (not Prehospital), 12; not peer reviewed, 4; Unable to locate, 3; Not English language, 3 |
